﻿=== wordpress支付宝插件 ===
Contributors: 帕克实验室
Donate link: http://www.pakelab.com/wordpress-alipay-plugins-online/
Tags: wordpress支付宝插件, 即时到帐,订单管理,自动发货,alipay,wordpress 支付宝,网店插件
Requires at least: 2.7
Tested up to: 3.0
Stable tag: trunk


== Description ==

如果你想在你的网站上出售虚拟物品，又不想时时刻刻呆在电脑前处理订单，那么wordpress支付宝插件是必选的，wordpress支付宝

插件可以实现即时到帐，自动发货，订单管理，全自动无人值守。

*<a href="http://www.pakelab.com/">作者：帕克实验室</a>

*<a href="http://www.pakelab.com/wp-alipay/">wordpress支付宝插件主页</a>
== Installation ==

1.上传alipay文件夹放到wordpress根目录下

2.上传wp-pay文件夹上传到wordpress插件目录下：`/wp-content/plugins/` 


3.把 `<?php include($_SERVER['DOCUMENT_ROOT'] . '/alipay/form.php'); ?>` 添加到文章模板内（single.php),一般放在`<?php the_content(); ?>`下面

4.激活插件

== Screenshots ==
screenshot-1.png